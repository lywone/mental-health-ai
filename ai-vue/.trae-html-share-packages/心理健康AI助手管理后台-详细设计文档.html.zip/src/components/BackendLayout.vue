<template>
  <div class="common-layout">
    <el-container>
      <Navbar></Navbar>
      <el-container>
        <Sidebar></Sidebar>
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>
<script setup>
import Sidebar from './Sidebar.vue'
import Navbar from './Navbar.vue'
</script>
<style lang="scss" scoped>
.common-layout {
  height: 100vh;
}
.el-container {
    flex-direction: column;
}
</style>
