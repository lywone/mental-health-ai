<template>
  <el-aside width="200px">
    <el-menu default-active="1">
      <el-menu-item index="1">首页</el-menu-item>
      <el-menu-item index="2">用户管理</el-menu-item>
      <el-menu-item index="3">角色管理</el-menu-item>
    </el-menu>
  </el-aside>
</template>
