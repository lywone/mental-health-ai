<template>
    <div class="navbar">
        顶部导航栏
    </div>
</template>
