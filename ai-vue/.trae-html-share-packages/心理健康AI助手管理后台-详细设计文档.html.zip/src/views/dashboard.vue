<template>
    <div class="dashboard">
        首页
    </div>
</template>
