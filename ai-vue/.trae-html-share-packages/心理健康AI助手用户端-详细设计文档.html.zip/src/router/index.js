import { createRouter, createWebHistory } from 'vue-router'
import BackendLayout from '@/components/BackendLayout.vue'
import { isLogin } from '@/auth'

// FR-G04：history 模式，后台路由统一前缀 /back/
const routes = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/Login.vue'),
    meta: { title: '登录' },
  },
  {
    path: '/back',
    component: BackendLayout,
    redirect: '/back/dashboard',
    children: [
      { path: 'dashboard', name: 'dashboard', component: () => import('@/views/dashboard.vue'), meta: { title: '数据分析' } },
      { path: 'articles', name: 'articles', component: () => import('@/views/articles.vue'), meta: { title: '知识文章' } },
      { path: 'consultations', name: 'consultations', component: () => import('@/views/consultations.vue'), meta: { title: '咨询记录' } },
      { path: 'moods', name: 'moods', component: () => import('@/views/moods.vue'), meta: { title: '情绪日志' } },
    ],
  },
  { path: '/', redirect: '/back/dashboard' },
  // 未匹配路由重定向到后台默认首页
  { path: '/:pathMatch(.*)*', redirect: '/back/dashboard' },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// FR-L02：登录态守卫
router.beforeEach((to) => {
  const authed = isLogin()
  // 未登录访问 /back/* → 重定向 /login 并携带 redirect 参数
  if (to.path.startsWith('/back') && !authed) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  // 已登录访问 /login → 重定向后台默认首页
  if (to.path === '/login' && authed) {
    return '/back/dashboard'
  }
})

router.afterEach((to) => {
  const title = to.meta?.title
  document.title = title ? `${title} · 心理健康AI助手管理后台` : '心理健康AI助手管理后台'
})

export default router
