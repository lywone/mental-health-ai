// 本地 Mock 数据（Q1 已确认：以详细设计文档第 4 章字段表为构造依据）
// 所有时间以「今天」为基准动态生成，保证统计卡片与图表数据自洽；
// 时间序列由明细数据派生，后续可整体替换为真实接口。

import { fmtMD } from '@/utils/format'

// ---------- 确定性伪随机（固定种子，刷新后数据稳定） ----------
function mulberry32(seed) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const rand = mulberry32(20260126)
const pick = (arr) => arr[Math.floor(rand() * arr.length)]
const randInt = (min, max) => min + Math.floor(rand() * (max - min + 1))

// ---------- 预置账号（Q2 假登录） ----------
export const ADMIN_ACCOUNT = { username: 'admin', password: '123456' }

// ---------- 用户 ----------
export const users = [
  { id: 'U1001', nickname: '小林' },
  { id: 'U1002', nickname: '阿哲' },
  { id: 'U1003', nickname: '叶叶' },
]

// ---------- 日期基准 ----------
const TODAY = new Date()
TODAY.setHours(0, 0, 0, 0)
const dayStart = (offset) => {
  const d = new Date(TODAY)
  d.setDate(d.getDate() - offset)
  return d
}
const atTime = (offsetDay, h, m) => {
  const d = dayStart(offsetDay)
  d.setHours(h, m, 0, 0)
  return d
}

// ---------- 情绪日志（字段表见设计文档 4.4） ----------
const MOOD_TEXTS = [
  '今天状态不错，按时完成了工作计划，晚上打算奖励自己一部电影。',
  '最近总是睡不好，白天也没精神，希望这个周期能快点过去。',
  '开会时被当众批评了，心情有点低落，写下来梳理一下情绪。',
  '和朋友聊了很久，把憋在心里的话都说出来了，感觉轻松多了。',
  '论文进度落后，有点焦虑，晚上去操场跑了三公里舒缓一下。',
  '今天没有什么特别的事，很平静的一天，给这样的日子打个分。',
  '失眠到凌晨两点，翻来覆去睡不着，脑子里全是没做完的事。',
  '和家人吵架了，很愤怒也很委屈，需要冷静下来再沟通。',
  '运动之后心情好了一些，决定把晨跑坚持下去。',
  '连续加班一周，感觉非常疲惫，效率也越来越低。',
  '上午效率很高，给自己点了杯咖啡，心情不错。',
  '面试被拒了，开始怀疑自己的能力，需要重新整理简历和心态。',
]
const MOOD_TAGS = ['开心', '平静', '焦虑', '低落', '愤怒', '疲惫']

function buildMoods() {
  const list = []
  let id = 1
  // 今日 2 条（保证「今日新增」有值）
  list.push({
    id: `M${String(id++).padStart(4, '0')}`,
    userId: 'U1001',
    time: atTime(0, 8, 15),
    score: 8,
    tags: ['平静'],
    content: '今天状态不错，按时完成了工作计划，晚上打算奖励自己一部电影。',
    sessionId: null,
  })
  list.push({
    id: `M${String(id++).padStart(4, '0')}`,
    userId: 'U1002',
    time: atTime(0, 12, 40),
    score: 5,
    tags: ['焦虑', '疲惫'],
    content: '论文进度落后，有点焦虑，晚上去操场跑了三公里舒缓一下。',
    sessionId: null,
  })
  // 近 29 天 23 条随机分布
  for (let i = 0; i < 23; i++) {
    const offset = randInt(1, 29)
    const score = randInt(2, 10)
    const tags = [pick(MOOD_TAGS)]
    if (rand() > 0.7) tags.push(pick(MOOD_TAGS))
    list.push({
      id: `M${String(id++).padStart(4, '0')}`,
      userId: pick(users).id,
      time: atTime(offset, randInt(6, 23), randInt(0, 59)),
      score,
      tags,
      content: pick(MOOD_TEXTS),
      sessionId: null,
    })
  }
  return list.sort((a, b) => b.time - a.time)
}
export const moods = buildMoods()

// ---------- 咨询会话（字段表见设计文档 4.3） ----------
const DIALOG_TEMPLATES = [
  [
    ['user', '最近总是睡不好，躺在床上翻来覆去一两个小时都睡不着。'],
    ['ai', '你好，愿意和我多聊聊最近的睡眠情况吗？大概是从什么时候开始的？'],
    ['user', '嗯，大概两周了吧，晚上要很久才能睡着。'],
    ['ai', '两周里有没有哪一晚相对好一些？当时和平时有什么不一样吗？'],
    ['user', '周末运动过之后那晚睡得还行。'],
    ['ai', '这是个很好的线索。规律运动对睡眠有帮助，我们可以从每天 20 分钟的散步开始试试。'],
    ['user', '好的，我试试看，睡前也少刷手机。'],
    ['ai', '非常棒的决心。睡前一小时可以试试放松练习，比如缓慢的深呼吸。期待你明天的反馈。'],
  ],
  [
    ['user', '最近工作压力很大，感觉快撑不住了。'],
    ['ai', '听起来你承受了很多，愿意具体说说是什么让你感到压力吗？'],
    ['user', '项目一直在赶进度，每天都要加班到很晚。'],
    ['ai', '长期的加班确实会消耗人的精力。这段时间你的休息和吃饭规律吗？'],
    ['user', '不太规律，经常忘了吃饭。'],
    ['ai', '身体状态会直接影响情绪。我们先从照顾好自己开始：固定三餐、每小时起来活动五分钟，可以吗？'],
    ['user', '好，我尽量做到。'],
    ['ai', '不必要求完美，尽力就好。压力很大的时候，随时可以来和我聊聊。'],
  ],
  [
    ['user', '和朋友闹矛盾了，心里一直堵得慌。'],
    ['ai', '和朋友产生矛盾确实让人难受。愿意说说发生了什么吗？'],
    ['user', '一件小事，TA 当着很多人的面开了我的玩笑。'],
    ['ai', '在他人面前被调侃，感到不舒服是很正常的。你当时有表达出自己的感受吗？'],
    ['user', '没有，只是笑了笑，回家越想越委屈。'],
    ['ai', '被压抑的感受不会自动消失。如果这段友谊对你重要，可以找个私下场合，平和地告诉 TA 你的感受。'],
    ['user', '嗯，我想想怎么开口。谢谢你。'],
    ['ai', '不客气。表达感受需要勇气，你已经在向前走了。'],
  ],
  [
    ['user', '感觉最近情绪一直很低落，对什么都提不起兴趣。'],
    ['ai', '谢谢你愿意说出来。这种「提不起兴趣」的状态持续多久了呢？'],
    ['user', '差不多一个月了，以前喜欢的事情现在也不想做。'],
    ['ai', '持续一个月的低兴趣状态值得认真对待。除了兴趣下降，睡眠和食欲有变化吗？'],
    ['user', '睡眠还行，就是容易累，吃得也少了。'],
    ['ai', '如果这种状态持续加重，建议寻求专业心理帮助，这不是软弱，而是对自己负责。同时我们可以先从每天一件小事开始。'],
    ['user', '好吧，我记录一下自己的状态。'],
    ['ai', '很好的开始。你随时可以来找我聊聊，我会一直在。'],
  ],
  [
    ['user', '明天要面试了，特别紧张，怕又搞砸。'],
    ['ai', '面试前的紧张说明你在意这次机会。愿意说说上次让你觉得「搞砸」的地方吗？'],
    ['user', '上次被问到职业规划时脑子一片空白。'],
    ['ai', '这属于常见的应激反应。我们可以提前准备一个 30 秒的简短回答，多练习几遍，紧张会小很多。'],
    ['user', '好主意，我晚上就写一版。'],
    ['ai', '另外记住：面试是双向选择，你不是在接受审判。祝你明天顺利。'],
    ['user', '谢谢，感觉没那么慌了。'],
    ['ai', '你已经做了能做的准备，剩下的交给临场发挥。加油！'],
  ],
]

function buildConsultations() {
  const list = []
  const offsets = [0, 1, 4, 7, 12, 18, 23, 29] // 今日 1 场 + 近期 7 场
  offsets.forEach((offset, i) => {
    const startH = randInt(9, 21)
    const start = atTime(offset, startH, pick([5, 12, 30, 47]))
    const tpl = pick(DIALOG_TEMPLATES)
    const inProgress = offset === 0
    const msgs = tpl.map(([from, text], idx) => ({
      from,
      time: new Date(start.getTime() + (idx + 1) * randInt(40, 180) * 1000),
      text,
    }))
    const ended = !inProgress
    const end = ended ? new Date(msgs[msgs.length - 1].time.getTime() + randInt(60, 300) * 1000) : null
    const durationMin = ended ? Math.max(1, Math.round((end - start) / 60000)) : null
    const dayKey = fmtMD(start).replace('-', '')
    list.push({
      id: `CS${dayKey}${String(i + 1).padStart(3, '0')}`,
      userId: pick(users).id,
      startTime: start,
      endTime: end,
      durationMin,
      messageCount: msgs.length,
      score: ended ? randInt(4, 10) : null, // 进行中会话无评分
      status: inProgress ? '进行中' : '已结束',
      messages: msgs,
    })
  })
  return list.sort((a, b) => b.startTime - a.startTime)
}
export const consultations = buildConsultations()

// ---------- 知识文章（字段表见设计文档 4.2） ----------
const ARTICLE_SEEDS = [
  ['认识情绪：情绪不是敌人，而是信使', '情绪管理'],
  ['四步走出情绪低谷：STOP 情绪急救法', '情绪管理'],
  ['为什么我们会焦虑？焦虑的自我觉察', '情绪管理'],
  ['科学睡眠指南：把失眠还给夜晚', '睡眠健康'],
  ['睡前一小时：打造你的入睡仪式感', '睡眠健康'],
  ['什么是心理健康？破除三个常见误区', '心理科普'],
  ['压力的运作机制：读懂身体的信号', '心理科普'],
  ['人际关系中的边界感：温和而坚定', '人际关系'],
  ['如何好好吵架：亲密关系中的非暴力沟通', '人际关系'],
  ['正念入门：把注意力温柔地拉回当下', '情绪管理'],
  ['社交倦怠：为什么越休息越累', '心理科普'],
  ['告别报复性熬夜：找回睡眠主动权', '睡眠健康'],
]
function buildArticles() {
  const statuses = ['已发布', '已发布', '已发布', '已发布', '已发布', '已发布', '已发布', '草稿', '草稿', '草稿', '已下架', '已下架']
  const paragraphs = [
    '在快节奏的生活中，情绪波动是每个人都会经历的自然现象。情绪本身没有好坏之分，它们更像是一封封信使，提醒我们内心的需要。',
    '第一步是觉察。当我们能够给情绪命名——「我现在感到焦虑」——大脑的杏仁核活跃度就会显著下降，这是情绪调节的开始。',
    '其次，尝试为情绪留出空间。不必急着摆脱它，可以问自己：这份感受想告诉我什么？是疲惫、委屈，还是未被满足的期待？',
    '研究显示，规律作息、适度运动与良好的社会支持，是心理韧性的三大基石。哪怕是每天十分钟的散步，也在悄悄重塑你的情绪基线。',
    '最后，请记住：寻求帮助是勇敢者的选择。当自我调节难以奏效时，向信任的人倾诉或寻求专业支持，都是对自己负责的方式。',
    '愿你在每一个起伏的日子里，都能温柔地接住自己。',
  ]
  return ARTICLE_SEEDS.map(([title, category], i) => {
    const status = statuses[i]
    const published = status !== '草稿'
    const body = paragraphs.slice(0, randInt(3, 6)).join('\n')
    return {
      id: `A${String(i + 1).padStart(3, '0')}`,
      title,
      category,
      cover: '',
      summary: body.slice(0, 60) + '…',
      content: body,
      status,
      views: published ? randInt(20, 300) : 0,
      publishTime: published ? atTime(randInt(1, 25), randInt(9, 20), randInt(0, 59)) : null,
    }
  })
}
export const articles = buildArticles()

// ---------- 时间序列（由明细派生，保证统计口径一致） ----------
const TREND_DAYS = 30

function eachTrendDay(fn) {
  const out = []
  for (let offset = TREND_DAYS - 1; offset >= 0; offset--) {
    const d = dayStart(offset)
    const dateStr = fmtMD(d)
    out.push(fn(dateStr, d))
  }
  return out
}
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()

// FR-D02 情绪趋势：{ date, avgScore(1位小数，无记录为 null), count }
export const emotionTrend = eachTrendDay((dateStr, d) => {
  const day = moods.filter((m) => sameDay(m.time, d))
  const avgScore = day.length ? +(day.reduce((s, m) => s + m.score, 0) / day.length).toFixed(1) : null
  return { date: dateStr, avgScore, count: day.length }
})

// FR-D03 咨询活动：{ date, count, userCount }
export const consultTrend = eachTrendDay((dateStr, d) => {
  const day = consultations.filter((c) => sameDay(c.startTime, d))
  return { date: dateStr, count: day.length, userCount: new Set(day.map((c) => c.userId)).size }
})

// FR-D04 活跃度趋势（Q4 占位口径：当日有情绪记录或咨询会话的去重用户数）
export const activityTrend = eachTrendDay((dateStr, d) => {
  const ids = new Set([
    ...moods.filter((m) => sameDay(m.time, d)).map((m) => m.userId),
    ...consultations.filter((c) => sameDay(c.startTime, d)).map((c) => c.userId),
  ])
  return { date: dateStr, activeUsers: ids.size }
})

// ---------- 统计卡（FR-D01） ----------
// Q3 占位口径：活跃用户 = 近 7 天内有情绪记录或咨询会话的用户
export function getStats() {
  const last7 = (t) => (TODAY - new Date(t.getFullYear(), t.getMonth(), t.getDate())) / 86400000 < 7
  const activeUserIds = new Set([
    ...moods.filter((m) => last7(m.time)).map((m) => m.userId),
    ...consultations.filter((c) => last7(c.startTime)).map((c) => c.userId),
  ])
  const isToday = (t) => sameDay(t, TODAY)
  const scores = moods.map((m) => m.score)
  return {
    totalUsers: users.length,
    activeUsers: activeUserIds.size,
    totalMoods: moods.length,
    moodsToday: moods.filter((m) => isToday(m.time)).length,
    totalConsults: consultations.length,
    consultsToday: consultations.filter((c) => isToday(c.startTime)).length,
    avgScore: scores.length ? (scores.reduce((s, v) => s + v, 0) / scores.length).toFixed(1) : null,
  }
}
