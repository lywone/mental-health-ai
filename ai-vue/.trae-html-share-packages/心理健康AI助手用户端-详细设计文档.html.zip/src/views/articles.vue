<template>
  <!-- 4.2 知识文章 /back/articles -->
  <div class="articles-page">
    <!-- 筛选栏 FR-A01 -->
    <div class="panel">
      <el-form inline class="filter-form" @submit.prevent>
        <el-form-item label="标题">
          <el-input v-model="filterDraft.keyword" placeholder="关键词搜索（标题）" clearable style="width: 200px" />
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="filterDraft.category" placeholder="全部分类" clearable style="width: 140px">
            <el-option v-for="c in CATEGORIES" :key="c" :label="c" :value="c" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterDraft.status" placeholder="全部状态" clearable style="width: 120px">
            <el-option v-for="s in STATUSES" :key="s" :label="s" :value="s" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="applyFilter">查询</el-button>
          <el-button @click="resetFilter">重置</el-button>
        </el-form-item>
        <el-form-item class="filter-right">
          <el-button type="primary" :icon="Plus" @click="openDialog()">新增文章</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 列表 -->
    <div class="panel mt16">
      <el-table :data="pageData" v-loading="loading" stripe>
        <el-table-column prop="title" label="标题" min-width="220" show-overflow-tooltip />
        <el-table-column prop="category" label="分类" width="110" />
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusType(row.status)" disable-transitions>{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="views" label="浏览量" width="90" />
        <el-table-column label="发布时间" width="160">
          <template #default="{ row }">{{ fmtDateTime(row.publishTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
            <el-button v-if="row.status === '已发布'" link type="primary" @click="togglePublish(row)">下架</el-button>
            <el-button v-else link type="primary" @click="togglePublish(row)">发布</el-button>
            <el-button link type="danger" @click="remove(row)">删除</el-button>
          </template>
        </el-table-column>
        <template #empty><el-empty description="暂无数据" /></template>
      </el-table>

      <!-- R4 分页 -->
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="filteredList.length"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        class="pager"
      />
    </div>

    <!-- 新增 / 编辑弹窗 FR-A02（图 4） -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑文章' : '新增文章'" width="640px" destroy-on-close>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="文章标题" prop="title">
          <el-input v-model="form.title" maxlength="50" show-word-limit placeholder="不超过 50 字" />
        </el-form-item>
        <el-form-item label="文章分类" prop="category">
          <el-select v-model="form.category" placeholder="请选择分类" style="width: 200px">
            <el-option v-for="c in CATEGORIES" :key="c" :label="c" :value="c" />
          </el-select>
        </el-form-item>
        <el-form-item label="封面图">
          <el-upload
            class="cover-upload"
            list-type="picture-card"
            :auto-upload="false"
            :limit="1"
            :file-list="coverList"
            :on-change="onCoverChange"
            :on-remove="() => (coverList = [])"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
        </el-form-item>
        <el-form-item label="摘要">
          <el-input v-model="form.summary" type="textarea" :rows="2" maxlength="100" show-word-limit placeholder="不填时展示正文前 50 字" />
        </el-form-item>
        <el-form-item label="正文内容" prop="content">
          <el-input v-model="form.content" type="textarea" :rows="8" placeholder="请输入正文（纯文本，Q5 待确认编辑形式）" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
// FR-A01 列表与筛选 / FR-A02 新增编辑 / FR-A03 发布下架（R5）/ FR-A04 删除
import { computed, reactive, ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import { articles } from '@/mock/data'
import { fmtDateTime } from '@/utils/format'

const CATEGORIES = ['心理科普', '情绪管理', '睡眠健康', '人际关系']
const STATUSES = ['草稿', '已发布', '已下架']

const list = ref([])
const loading = ref(true)
onMounted(() => {
  // 模拟加载
  setTimeout(() => {
    list.value = structuredClone(articles)
    loading.value = false
  }, 300)
})

// ---------- 筛选（点查询才应用，回到第 1 页） ----------
const filterDraft = reactive({ keyword: '', category: null, status: null })
const filter = reactive({ keyword: '', category: null, status: null })
function applyFilter() {
  Object.assign(filter, filterDraft)
  page.value = 1
}
function resetFilter() {
  filterDraft.keyword = ''
  filterDraft.category = null
  filterDraft.status = null
  Object.assign(filter, filterDraft)
  page.value = 1
}

// ---------- 分页（R4：默认 10 条 / 10-20-50） ----------
const page = ref(1)
const pageSize = ref(10)
const filteredList = computed(() =>
  list.value.filter(
    (a) =>
      (!filter.keyword || a.title.includes(filter.keyword)) &&
      (!filter.category || a.category === filter.category) &&
      (!filter.status || a.status === filter.status),
  ),
)
const pageData = computed(() => filteredList.value.slice((page.value - 1) * pageSize.value, page.value * pageSize.value))

function statusType(status) {
  return { 草稿: 'warning', 已发布: 'success', 已下架: 'info' }[status] || 'info'
}

// ---------- 新增 / 编辑 ----------
const dialogVisible = ref(false)
const isEdit = ref(false)
const editingId = ref(null)
const formRef = ref(null)
const coverList = ref([])
const form = reactive({ title: '', category: null, cover: '', summary: '', content: '' })
const rules = {
  title: [
    { required: true, message: '请输入文章标题', trigger: 'blur' },
    { max: 50, message: '标题不超过 50 字', trigger: 'blur' },
  ],
  category: [{ required: true, message: '请选择分类', trigger: 'change' }],
  content: [{ required: true, message: '请输入正文内容', trigger: 'blur' }],
}

function openDialog(row) {
  isEdit.value = !!row
  editingId.value = row?.id ?? null
  form.title = row?.title ?? ''
  form.category = row?.category ?? null
  form.cover = row?.cover ?? ''
  form.summary = row?.summary ?? ''
  form.content = row?.content ?? ''
  coverList.value = row?.cover ? [{ name: 'cover', url: row.cover }] : []
  dialogVisible.value = true
}

function onCoverChange(file) {
  coverList.value = [file]
  // 本地 Mock：读取为 dataURL 存储
  const reader = new FileReader()
  reader.onload = (e) => (form.cover = e.target.result)
  reader.readAsDataURL(file.raw)
}

async function save() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  if (isEdit.value) {
    const target = list.value.find((a) => a.id === editingId.value)
    Object.assign(target, { title: form.title, category: form.category, summary: form.summary, content: form.content, cover: form.cover || '' })
    ElMessage.success('保存成功')
  } else {
    list.value.unshift({
      id: `A${Date.now()}`,
      title: form.title,
      category: form.category,
      cover: form.cover || '',
      summary: form.summary,
      content: form.content,
      status: '草稿', // 新增默认草稿
      views: 0,
      publishTime: null,
    })
    ElMessage.success('新增成功')
  }
  dialogVisible.value = false
}

// ---------- FR-A03 发布 / 下架（R5 状态流转） ----------
function togglePublish(row) {
  if (row.status === '已发布') {
    row.status = '已下架'
    ElMessage.success(`《${row.title}》已下架`)
  } else {
    if (!row.publishTime) row.publishTime = new Date() // 首次发布时写入发布时间
    row.status = '已发布'
    ElMessage.success(`《${row.title}》已发布`)
  }
}

// ---------- FR-A04 删除（二次确认） ----------
function remove(row) {
  ElMessageBox.confirm(`确认删除文章《${row.title}》吗？删除后不可恢复。`, '删除文章', {
    confirmButtonText: '删除',
    cancelButtonText: '取消',
    type: 'warning',
  })
    .then(() => {
      list.value = list.value.filter((a) => a.id !== row.id)
      ElMessage.success('删除成功')
    })
    .catch(() => {})
}
</script>

<style scoped>
.mt16 {
  margin-top: 16px;
}
.panel {
  background: #fff;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  padding: 16px;
}
.filter-form :deep(.el-form-item) {
  margin-bottom: 0;
}
.filter-right {
  margin-left: auto;
}
.pager {
  margin-top: 14px;
  justify-content: flex-end;
}
.cover-upload :deep(.el-upload--picture-card) {
  width: 80px;
  height: 80px;
}
.cover-upload :deep(.el-upload-list--picture-card .el-upload-list__item) {
  width: 80px;
  height: 80px;
}
</style>
