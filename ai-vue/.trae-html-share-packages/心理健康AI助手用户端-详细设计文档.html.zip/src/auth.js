// 前端假登录态管理（Q2 已确认，详见设计文档 4.5）
// 正式环境需替换为后端鉴权。

const AUTH_KEY = 'back_auth'

export function isLogin() {
  return !!localStorage.getItem(AUTH_KEY)
}

export function setLogin(username) {
  localStorage.setItem(AUTH_KEY, JSON.stringify({ username, loginAt: Date.now() }))
}

export function clearLogin() {
  localStorage.removeItem(AUTH_KEY)
}

export function currentUser() {
  try {
    return JSON.parse(localStorage.getItem(AUTH_KEY))?.username || 'admin'
  } catch {
    return 'admin'
  }
}
